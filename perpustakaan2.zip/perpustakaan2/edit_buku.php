<?php

session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

include "config/koneksi.php";

$id = $_GET['id'];

$query = mysqli_query(
    $koneksi,
    "SELECT * FROM buku WHERE id_buku='$id'"
);

$data = mysqli_fetch_assoc($query);

if (!$data) {
    echo "<script>
            alert('Data buku tidak ditemukan!');
            window.location='buku.php';
          </script>";
    exit;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Edit Buku | Perpustakaan</title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >

</head>

<body>


<!-- SIDEBAR -->

<div class="sidebar">

    <div class="sidebar-logo">

        <div class="logo-icon">
            📚
        </div>

        <div class="logo-text">
            Perpustakaan<span>.</span>
        </div>

    </div>


    <!-- PROFIL ADMIN -->

    <div class="admin-profile">

        <div class="admin-avatar">
            A
        </div>

        <div class="admin-info">

            <strong>
                <?= htmlspecialchars($_SESSION['admin']) ?>
            </strong>

            <small>
                Administrator
            </small>

        </div>

    </div>


    <div class="menu-title">
        Menu Utama
    </div>


    <ul class="sidebar-menu">

        <li>

            <a href="dashboard.php">

                <span>🏠</span>

                Dashboard

            </a>

        </li>


        <li>

            <a
                href="buku.php"
                class="active"
            >

                <span>📖</span>

                Daftar Buku Arsip

            </a>

        </li>


        <li>

            <a href="peminjaman.php">

                <span>📋</span>

                Peminjaman

            </a>

        </li>


        <li>

            <a
                href="logout.php"
                class="logout"
                onclick="return confirm('Yakin ingin logout?')"
            >

                <span>🚪</span>

                Logout

            </a>

        </li>

    </ul>

</div>



<!-- MAIN CONTENT -->

<div class="main-content">


    <!-- HEADER -->

    <div class="top-header">

        <div class="header-left">

            <h1>
                Edit Buku
            </h1>

            <p>
                Perbarui informasi koleksi buku.
            </p>

        </div>


        <div class="header-date">

            ✏️

            Edit Koleksi

        </div>

    </div>



    <!-- FORM -->

    <div class="form-box">


        <div
            style="
                display:flex;
                align-items:center;
                gap:12px;
                margin-bottom:25px;
            "
        >

            <div
                style="
                    width:48px;
                    height:48px;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    background:#fff7df;
                    border-radius:12px;
                    font-size:22px;
                "
            >
                ✏️
            </div>


            <div>

                <h2 style="margin-bottom:3px;">
                    Edit Informasi Buku
                </h2>

                <p
                    style="
                        color:#94a3b8;
                        font-size:11px;
                    "
                >
                    Ubah data buku sesuai informasi terbaru.
                </p>

            </div>

        </div>



        <form
            action="proses_edit_buku.php"
            method="POST"
        >


            <!-- ID BUKU -->

            <input
                type="hidden"
                name="id_buku"
                value="<?= $data['id_buku'] ?>"
            >


            <!-- JUDUL -->

            <label>
                Judul Buku
            </label>

            <input
                type="text"
                name="judul"
                value="<?= htmlspecialchars($data['judul']) ?>"
                placeholder="Masukkan judul buku"
                required
            >


            <!-- TAHUN TERBIT -->

            <label>
                Tahun Terbit
            </label>

            <input
                type="number"
                name="tahun_terbit"
                value="<?= $data['tahun_terbit'] ?>"
                min="1900"
                max="2100"
                required
            >


            <!-- STOK -->

            <label>
                Stok Buku
            </label>

            <input
                type="number"
                name="stok"
                value="<?= $data['stok'] ?>"
                min="0"
                required
            >


            <!-- BUTTON -->

            <div
                style="
                    display:flex;
                    gap:10px;
                    margin-top:8px;
                "
            >

                <button
                    type="submit"
                >

                    💾 Simpan Perubahan

                </button>


                <a
                    href="buku.php"
                    class="btn btn-secondary"
                >

                    ← Batal

                </a>

            </div>


        </form>


    </div>


</div>


</body>

</html>