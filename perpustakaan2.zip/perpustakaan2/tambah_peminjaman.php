<?php

session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

include "config/koneksi.php";

/* Ambil buku yang masih tersedia */

$query_buku = mysqli_query(
    $koneksi,
    "SELECT * FROM buku
     WHERE stok > 0
     ORDER BY judul ASC"
);

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Tambah Peminjaman | Perpustakaan</title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >

</head>

<body>


<!-- =========================
     SIDEBAR
========================= -->

<div class="sidebar">


    <!-- LOGO -->

    <div class="sidebar-logo">

        <div class="logo-icon">
            📚
        </div>

        <div class="logo-text">
            Perpustakaan<span>.</span>
        </div>

    </div>


    <!-- PROFIL ADMIN -->

    <div class="admin-profile">

        <div class="admin-avatar">
            A
        </div>

        <div class="admin-info">

            <strong>
                <?= htmlspecialchars($_SESSION['admin']) ?>
            </strong>

            <small>
                Administrator
            </small>

        </div>

    </div>


    <!-- MENU -->

    <div class="menu-title">
        Menu Utama
    </div>


    <ul class="sidebar-menu">


        <li>

            <a href="dashboard.php">

                <span>🏠</span>

                Dashboard

            </a>

        </li>


        <li>

            <a href="buku.php">

                <span>📖</span>

                Daftar Buku Arsip

            </a>

        </li>


        <li>

            <a
                href="peminjaman.php"
                class="active"
            >

                <span>📋</span>

                Peminjaman

            </a>

        </li>


        <li>

            <a
                href="logout.php"
                class="logout"
                onclick="return confirm('Yakin ingin logout?')"
            >

                <span>🚪</span>

                Logout

            </a>

        </li>


    </ul>

</div>



<!-- =========================
     MAIN CONTENT
========================= -->

<div class="main-content">


    <!-- HEADER -->

    <div class="top-header">

        <div class="header-left">

            <h1>
                Tambah Peminjaman
            </h1>

            <p>
                Catat transaksi peminjaman buku baru.
            </p>

        </div>


        <div class="header-date">

            📋

            Transaksi Baru

        </div>

    </div>



    <!-- =========================
         FORM
    ========================= -->

    <div class="form-box">


        <div
            style="
                display:flex;
                align-items:center;
                gap:12px;
                margin-bottom:25px;
            "
        >

            <div
                style="
                    width:48px;
                    height:48px;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    background:#eff6ff;
                    border-radius:12px;
                    font-size:22px;
                "
            >
                📋
            </div>


            <div>

                <h2 style="margin-bottom:3px;">
                    Informasi Peminjaman
                </h2>

                <p
                    style="
                        color:#94a3b8;
                        font-size:11px;
                    "
                >
                    Isi data peminjaman dengan lengkap.
                </p>

            </div>

        </div>



        <form
            action="proses_peminjaman.php"
            method="POST"
        >


            <!-- NAMA PEMINJAM -->

            <label>
                Nama Peminjam
            </label>

            <input
                type="text"
                name="nama_peminjam"
                placeholder="Masukkan nama peminjam"
                required
            >



            <!-- PILIH BUKU -->

            <label>
                Pilih Buku
            </label>

            <select
                name="id_buku"
                required
            >

                <option value="">
                    -- Pilih Buku --
                </option>


                <?php

                if (
                    mysqli_num_rows(
                        $query_buku
                    ) > 0
                ):

                    while (
                        $buku = mysqli_fetch_assoc(
                            $query_buku
                        )
                    ):

                ?>

                    <option
                        value="<?= $buku['id_buku'] ?>"
                    >

                        <?= htmlspecialchars(
                            $buku['judul']
                        ) ?>

                        — Stok:
                        <?= $buku['stok'] ?>

                    </option>


                <?php

                    endwhile;

                else:

                ?>

                    <option value="" disabled>

                        Tidak ada buku yang tersedia

                    </option>

                <?php endif; ?>


            </select>



            <!-- TANGGAL PINJAM -->

            <label>
                Tanggal Pinjam
            </label>

            <input
                type="date"
                name="tanggal_pinjam"
                value="<?= date('Y-m-d') ?>"
                required
            >



            <!-- TANGGAL KEMBALI -->

            <label>
                Tanggal Kembali
                <span
                    style="
                        color:#94a3b8;
                        font-weight:400;
                    "
                >
                    (Opsional)
                </span>
            </label>

            <input
                type="date"
                name="tanggal_kembali"
            >



            <!-- INFO -->

            <div
                style="
                    display:flex;
                    gap:10px;
                    align-items:flex-start;
                    background:#eff6ff;
                    border:1px solid #dbeafe;
                    color:#1d4ed8;
                    padding:13px;
                    border-radius:9px;
                    font-size:11px;
                    line-height:1.5;
                    margin-bottom:20px;
                "
            >

                <span style="font-size:16px;">
                    ℹ️
                </span>

                <span>
                    Stok buku akan otomatis berkurang
                    setelah peminjaman berhasil disimpan.
                </span>

            </div>



            <!-- BUTTON -->

            <div
                style="
                    display:flex;
                    gap:10px;
                    margin-top:8px;
                "
            >

                <button
                    type="submit"
                >

                    💾 Simpan Peminjaman

                </button>


                <a
                    href="peminjaman.php"
                    class="btn btn-secondary"
                >

                    ← Batal

                </a>

            </div>


        </form>


    </div>


</div>


</body>

</html>