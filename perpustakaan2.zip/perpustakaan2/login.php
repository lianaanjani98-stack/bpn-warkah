<?php

session_start();

if (isset($_SESSION['admin'])) {
    header("Location: dashboard.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login Admin - Pinjaman Warkah</title>

    <link rel="stylesheet" href="css/style.css">

</head>

<body class="login-page">

    <div class="login-box">

        <div style="
            text-align: center;
            font-size: 45px;
            margin-bottom: 10px;
        ">
            📚
        </div>

        <h1>Pinjaman Warkah</h1>

        <p>
            Silakan login untuk masuk ke halaman admin
        </p>


        <form action="proses_login.php" method="POST">

            <div class="form-group">

                <label>Username</label>

                <input
                    type="text"
                    name="username"
                    placeholder="Masukkan username"
                    autocomplete="username"
                    required
                >

            </div>


            <div class="form-group">

                <label>Password</label>

                <input
                    type="password"
                    name="password"
                    placeholder="Masukkan password"
                    autocomplete="current-password"
                    required
                >

            </div>


            <button
                type="submit"
                class="btn-login"
            >
                Masuk ke Dashboard
            </button>

        </form>


        <div style="
            text-align: center;
            margin-top: 25px;
            color: #94a3b8;
            font-size: 12px;
        ">
            Sistem Informasi Perpustakaan
        </div>

    </div>

</body>

</html>