<?php

session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

include "config/koneksi.php";


$id_buku = $_POST['id_buku'];
$judul = $_POST['judul'];
$tahun_terbit = $_POST['tahun_terbit'];
$stok = $_POST['stok'];


$query = mysqli_query(
    $koneksi,
    "UPDATE buku SET

        judul='$judul',
        tahun_terbit='$tahun_terbit',
        stok='$stok'

     WHERE id_buku='$id_buku'"
);


if ($query) {

    echo "<script>

            alert('Buku berhasil diperbarui!');

            window.location='buku.php';

          </script>";

} else {

    echo "Gagal memperbarui buku: "
         . mysqli_error($koneksi);

}

?>