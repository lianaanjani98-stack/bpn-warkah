<?php

session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

include "config/koneksi.php";


$nama_peminjam = $_POST['nama_peminjam'];

$id_buku = $_POST['id_buku'];

$tanggal_pinjam = $_POST['tanggal_pinjam'];

$tanggal_kembali = !empty($_POST['tanggal_kembali'])
    ? $_POST['tanggal_kembali']
    : NULL;


// CEK BUKU
$cek_buku = mysqli_query(
    $koneksi,
    "SELECT stok FROM buku
     WHERE id_buku='$id_buku'"
);


$buku = mysqli_fetch_assoc($cek_buku);


if (!$buku) {

    echo "<script>

            alert('Buku tidak ditemukan!');

            window.location='tambah_peminjaman.php';

          </script>";

    exit;

}


// CEK STOK
if ($buku['stok'] <= 0) {

    echo "<script>

            alert('Stok buku habis!');

            window.location='tambah_peminjaman.php';

          </script>";

    exit;

}


// SIMPAN PEMINJAMAN

if ($tanggal_kembali === NULL) {

    $query = mysqli_query(
        $koneksi,
        "INSERT INTO peminjaman
        (
            id_buku,
            nama_peminjam,
            tanggal_pinjam,
            tanggal_kembali,
            status
        )
        VALUES
        (
            '$id_buku',
            '$nama_peminjam',
            '$tanggal_pinjam',
            NULL,
            'Dipinjam'
        )"
    );

} else {

    $query = mysqli_query(
        $koneksi,
        "INSERT INTO peminjaman
        (
            id_buku,
            nama_peminjam,
            tanggal_pinjam,
            tanggal_kembali,
            status
        )
        VALUES
        (
            '$id_buku',
            '$nama_peminjam',
            '$tanggal_pinjam',
            '$tanggal_kembali',
            'Dipinjam'
        )"
    );

}


// BERHASIL
if ($query) {

    mysqli_query(
        $koneksi,
        "UPDATE buku
         SET stok = stok - 1
         WHERE id_buku='$id_buku'"
    );


    echo "<script>

            alert('Peminjaman berhasil ditambahkan!');

            window.location='peminjaman.php';

          </script>";

} else {

    echo "Gagal menambahkan peminjaman: "
         . mysqli_error($koneksi);

}

?>