<?php

session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

include "config/koneksi.php";

/* =========================
   DATA STATISTIK
========================= */

$total_buku = mysqli_fetch_assoc(
    mysqli_query(
        $koneksi,
        "SELECT COUNT(*) AS total FROM buku"
    )
)['total'];

$total_peminjaman = mysqli_fetch_assoc(
    mysqli_query(
        $koneksi,
        "SELECT COUNT(*) AS total FROM peminjaman"
    )
)['total'];

$total_dipinjam = mysqli_fetch_assoc(
    mysqli_query(
        $koneksi,
        "SELECT COUNT(*) AS total
         FROM peminjaman
         WHERE status='Dipinjam'"
    )
)['total'];

$total_dikembalikan = mysqli_fetch_assoc(
    mysqli_query(
        $koneksi,
        "SELECT COUNT(*) AS total
         FROM peminjaman
         WHERE status='Dikembalikan'"
    )
)['total'];


/* =========================
   PEMINJAMAN TERBARU
========================= */

$data_peminjaman = mysqli_query(
    $koneksi,
    "SELECT
        peminjaman.*,
        buku.judul
     FROM peminjaman
     INNER JOIN buku
     ON peminjaman.id_buku = buku.id_buku
     ORDER BY peminjaman.id_peminjaman DESC
     LIMIT 5"
);


/* =========================
   TANGGAL INDONESIA
========================= */

$hari = [
    "Sunday" => "Minggu",
    "Monday" => "Senin",
    "Tuesday" => "Selasa",
    "Wednesday" => "Rabu",
    "Thursday" => "Kamis",
    "Friday" => "Jumat",
    "Saturday" => "Sabtu"
];

$bulan = [
    "January" => "Januari",
    "February" => "Februari",
    "March" => "Maret",
    "April" => "April",
    "May" => "Mei",
    "June" => "Juni",
    "July" => "Juli",
    "August" => "Agustus",
    "September" => "September",
    "October" => "Oktober",
    "November" => "November",
    "December" => "Desember"
];

$nama_hari = $hari[date("l")];

$tanggal = date("d F Y");

$tanggal = strtr(
    $tanggal,
    $bulan
);

$tanggal_lengkap = $nama_hari . ", " . $tanggal;

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Dashboard | Perpustakaan</title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >

</head>

<body>


<!-- =========================
     SIDEBAR
========================= -->

<div class="sidebar">


    <!-- LOGO -->

    <div class="sidebar-logo">

        <div class="logo-icon">
            📚
        </div>

        <div class="logo-text">
            Pinjaman Warkah<span>.</span>
        </div>

    </div>


    <!-- PROFIL ADMIN -->

    <div class="admin-profile">

        <div class="admin-avatar">
            A
        </div>

        <div class="admin-info">

            <strong>
                <?= htmlspecialchars($_SESSION['admin']) ?>
            </strong>

            <small>
                Administrator
            </small>

        </div>

    </div>


    <!-- JUDUL MENU -->

    <div class="menu-title">
        Menu Utama
    </div>


    <!-- MENU -->

    <ul class="sidebar-menu">


        <!-- DASHBOARD -->

        <li>

            <a
                href="dashboard.php"
                class="active"
            >

                <span>
                    🏠
                </span>

                Dashboard

            </a>

        </li>


        <!-- BUKU -->

        <li>

            <a href="buku.php">

                <span>
                    📖
                </span>

                Daftar Buku Arsip

            </a>

        </li>


        <!-- PEMINJAMAN -->

        <li>

            <a href="peminjaman.php">

                <span>
                    📋
                </span>

                Peminjaman

            </a>

        </li>


        <!-- LOGOUT -->

        <li>

            <a
                href="logout.php"
                class="logout"
                onclick="return confirm('Yakin ingin logout?')"
            >

                <span>
                    🚪
                </span>

                Logout

            </a>

        </li>


    </ul>

</div>



<!-- =========================
     MAIN CONTENT
========================= -->

<div class="main-content">


    <!-- HEADER -->

    <div class="top-header">


        <div class="header-left">

            <h1>
                Dashboard
            </h1>

            <p>
                Kelola data dan aktivitas perpustakaan.
            </p>

        </div>


        <div class="header-date">

            📅

            <?= $tanggal_lengkap ?>

        </div>


    </div>



    <!-- =========================
         WELCOME
    ========================= -->

    <div class="welcome">

        <h2>
            Selamat datang,
            <?= htmlspecialchars($_SESSION['admin']) ?> 👋
        </h2>

        <p>
            Berikut adalah ringkasan informasi
            perpustakaan kamu hari ini.
        </p>

    </div>



    <!-- =========================
         STATISTIK
    ========================= -->

    <div class="cards">


        <!-- TOTAL BUKU -->

        <div class="card">

            <div class="card-icon">
                📚
            </div>

            <div class="card-info">

                <h3>
                    TOTAL BUKU
                </h3>

                <div class="number">
                    <?= $total_buku ?>
                </div>

                <p>
                    Koleksi buku
                </p>

            </div>

        </div>



        <!-- TOTAL PEMINJAMAN -->

        <div class="card">

            <div class="card-icon">
                📋
            </div>

            <div class="card-info">

                <h3>
                    TOTAL PEMINJAMAN
                </h3>

                <div class="number">
                    <?= $total_peminjaman ?>
                </div>

                <p>
                    Seluruh transaksi
                </p>

            </div>

        </div>



        <!-- SEDANG DIPINJAM -->

        <div class="card">

            <div class="card-icon">
                📤
            </div>

            <div class="card-info">

                <h3>
                    SEDANG DIPINJAM
                </h3>

                <div class="number">
                    <?= $total_dipinjam ?>
                </div>

                <p>
                    Belum dikembalikan
                </p>

            </div>

        </div>



        <!-- DIKEMBALIKAN -->

        <div class="card">

            <div class="card-icon">
                📥
            </div>

            <div class="card-info">

                <h3>
                    DIKEMBALIKAN
                </h3>

                <div class="number">
                    <?= $total_dikembalikan ?>
                </div>

                <p>
                    Sudah kembali
                </p>

            </div>

        </div>


    </div>



    <!-- =========================
         TABEL PEMINJAMAN
    ========================= -->

    <div class="content-box">


        <div class="content-header">


            <div>

                <h2>
                    Peminjaman Terbaru
                </h2>

                <p>
                    Menampilkan 5 transaksi terakhir
                </p>

            </div>


            <a
                href="peminjaman.php"
                class="btn btn-primary"
            >

                📋

                Lihat Semua

            </a>


        </div>



        <table>


            <thead>

                <tr>

                    <th>
                        No
                    </th>

                    <th>
                        Peminjam
                    </th>

                    <th>
                        Buku
                    </th>

                    <th>
                        Tanggal Pinjam
                    </th>

                    <th>
                        Status
                    </th>

                </tr>

            </thead>



            <tbody>


            <?php

            $no = 1;

            if (mysqli_num_rows($data_peminjaman) > 0):

                while (
                    $data = mysqli_fetch_assoc(
                        $data_peminjaman
                    )
                ):

            ?>


                <tr>


                    <td>
                        <?= $no++ ?>
                    </td>


                    <td>

                        <strong>
                            <?= htmlspecialchars(
                                $data['nama_peminjam']
                            ) ?>
                        </strong>

                    </td>


                    <td>

                        <?= htmlspecialchars(
                            $data['judul']
                        ) ?>

                    </td>


                    <td>

                        <?= date(
                            "d/m/Y",
                            strtotime(
                                $data['tanggal_pinjam']
                            )
                        ) ?>

                    </td>


                    <td>


                        <?php

                        if (
                            $data['status']
                            == 'Dipinjam'
                        ):

                        ?>

                            <span
                                class="status status-dipinjam"
                            >
                                Dipinjam
                            </span>


                        <?php else: ?>


                            <span
                                class="status status-dikembalikan"
                            >
                                Dikembalikan
                            </span>


                        <?php endif; ?>


                    </td>


                </tr>


            <?php

                endwhile;

            else:

            ?>


                <tr>

                    <td
                        colspan="5"
                        style="
                            text-align:center;
                            padding:35px;
                            color:#94a3b8;
                        "
                    >

                        📭

                        <br><br>

                        Belum ada data peminjaman.

                    </td>

                </tr>


            <?php endif; ?>


            </tbody>


        </table>


    </div>


</div>


</body>

</html>