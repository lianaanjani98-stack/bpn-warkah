<?php

session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

include "config/koneksi.php";

/* =====================================================
   PROSES HAPUS PEMINJAMAN
===================================================== */

if (isset($_GET['hapus'])) {

    $id_peminjaman = intval($_GET['hapus']);

    // Ambil data peminjaman terlebih dahulu
    $cek = mysqli_query(
        $koneksi,
        "SELECT id_buku, status 
         FROM peminjaman 
         WHERE id_peminjaman = $id_peminjaman"
    );

    if (mysqli_num_rows($cek) > 0) {

        $data_hapus = mysqli_fetch_assoc($cek);

        $id_buku = intval($data_hapus['id_buku']);
        $status  = $data_hapus['status'];

        // Mulai transaksi
        mysqli_begin_transaction($koneksi);

        try {

            /*
             * Jika status masih Dipinjam,
             * stok buku dikembalikan +1
             */
            if ($status == 'Dipinjam') {

                $update_stok = mysqli_query(
                    $koneksi,
                    "UPDATE buku
                     SET stok = stok + 1
                     WHERE id_buku = $id_buku"
                );

                if (!$update_stok) {
                    throw new Exception("Gagal mengembalikan stok buku.");
                }
            }

            // Hapus data peminjaman
            $hapus = mysqli_query(
                $koneksi,
                "DELETE FROM peminjaman
                 WHERE id_peminjaman = $id_peminjaman"
            );

            if (!$hapus) {
                throw new Exception("Gagal menghapus data peminjaman.");
            }

            // Simpan perubahan
            mysqli_commit($koneksi);

            echo "<script>
                    alert('Data peminjaman berhasil dihapus!');
                    window.location='peminjaman.php';
                  </script>";
            exit;

        } catch (Exception $e) {

            // Batalkan perubahan jika terjadi error
            mysqli_rollback($koneksi);

            echo "<script>
                    alert('Data peminjaman gagal dihapus!');
                    window.location='peminjaman.php';
                  </script>";
            exit;
        }

    } else {

        echo "<script>
                alert('Data peminjaman tidak ditemukan!');
                window.location='peminjaman.php';
              </script>";
        exit;
    }
}


/* =====================================================
   AMBIL DATA PEMINJAMAN
===================================================== */

$query = mysqli_query(
    $koneksi,
    "SELECT
        peminjaman.*,
        buku.judul
     FROM peminjaman
     INNER JOIN buku
     ON peminjaman.id_buku = buku.id_buku
     ORDER BY peminjaman.id_peminjaman DESC"
);

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Peminjaman | Warkah</title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >

    <style>

        /* =========================
           TOMBOL HAPUS
        ========================= */

        .btn-hapus {
            display: inline-block;
            padding: 9px 14px;
            margin-left: 5px;
            background: #ef4444;
            color: white;
            text-decoration: none;
            border-radius: 7px;
            font-size: 12px;
            font-weight: 600;
            border: none;
            cursor: pointer;
        }

        .btn-hapus:hover {
            background: #dc2626;
        }

        /* Supaya tombol aksi tidak terlalu sempit */

        td:last-child {
            white-space: nowrap;
        }

    </style>

</head>

<body>


<!-- =========================
     SIDEBAR
========================= -->

<div class="sidebar">


    <div class="sidebar-logo">

        <div class="logo-icon">
            📚
        </div>

        <div class="logo-text">
            Pinjaman Warkah<span>.</span>
        </div>

    </div>


    <!-- PROFIL ADMIN -->

    <div class="admin-profile">

        <div class="admin-avatar">
            A
        </div>

        <div class="admin-info">

            <strong>
                <?= htmlspecialchars($_SESSION['admin']) ?>
            </strong>

            <small>
                Administrator
            </small>

        </div>

    </div>


    <div class="menu-title">
        Menu Utama
    </div>


    <ul class="sidebar-menu">


        <!-- DASHBOARD -->

        <li>

            <a href="dashboard.php">

                <span>
                    🏠
                </span>

                Dashboard

            </a>

        </li>


        <!-- BUKU -->

        <li>

            <a href="buku.php">

                <span>
                    📖
                </span>

                Daftar Buku Arsip

            </a>

        </li>


        <!-- PEMINJAMAN -->

        <li>

            <a
                href="peminjaman.php"
                class="active"
            >

                <span>
                    📋
                </span>

                Peminjaman

            </a>

        </li>


        <!-- LOGOUT -->

        <li>

            <a
                href="logout.php"
                class="logout"
                onclick="return confirm('Yakin ingin logout?')"
            >

                <span>
                    🚪
                </span>

                Logout

            </a>

        </li>


    </ul>

</div>



<!-- =========================
     MAIN CONTENT
========================= -->

<div class="main-content">


    <!-- HEADER -->

    <div class="top-header">


        <div class="header-left">

            <h1>
                Peminjaman
            </h1>

            <p>
                Kelola seluruh transaksi peminjaman buku.
            </p>

        </div>


        <div class="header-date">

            📋

            Data Peminjaman

        </div>


    </div>



    <!-- =========================
         CONTENT
    ========================= -->

    <div class="content-box">


        <div class="content-header">


            <div>

                <h2>
                    Data Peminjaman
                </h2>

                <p>
                    Riwayat dan status peminjaman buku
                </p>

            </div>


            <a
                href="tambah_peminjaman.php"
                class="btn btn-primary"
            >

                ＋ Tambah Peminjaman

            </a>


        </div>



        <!-- =========================
             TABLE
        ========================= -->

        <table>


            <thead>

                <tr>

                    <th>
                        No
                    </th>

                    <th>
                        Peminjam
                    </th>

                    <th>
                        Buku
                    </th>

                    <th>
                        Tanggal Pinjam
                    </th>

                    <th>
                        Tanggal Kembali
                    </th>

                    <th>
                        Status
                    </th>

                    <th>
                        Aksi
                    </th>

                </tr>

            </thead>


            <tbody>


            <?php

            $no = 1;

            if (mysqli_num_rows($query) > 0):

                while (
                    $data = mysqli_fetch_assoc($query)
                ):

            ?>


                <tr>


                    <!-- NOMOR -->

                    <td>

                        <?= $no++ ?>

                    </td>


                    <!-- PEMINJAM -->

                    <td>

                        <strong>

                            <?= htmlspecialchars(
                                $data['nama_peminjam']
                            ) ?>

                        </strong>

                    </td>


                    <!-- BUKU -->

                    <td>

                        📖

                        <?= htmlspecialchars(
                            $data['judul']
                        ) ?>

                    </td>


                    <!-- TANGGAL PINJAM -->

                    <td>

                        <?= date(
                            "d/m/Y",
                            strtotime(
                                $data['tanggal_pinjam']
                            )
                        ) ?>

                    </td>


                    <!-- TANGGAL KEMBALI -->

                    <td>

                        <?php

                        if (
                            !empty(
                                $data['tanggal_kembali']
                            )
                        ) {

                            echo date(
                                "d/m/Y",
                                strtotime(
                                    $data['tanggal_kembali']
                                )
                            );

                        } else {

                            echo '<span style="color:#94a3b8;">
                                    —
                                  </span>';

                        }

                        ?>

                    </td>


                    <!-- STATUS -->

                    <td>


                        <?php

                        if (
                            $data['status']
                            == 'Dipinjam'
                        ):

                        ?>

                            <span
                                class="status status-dipinjam"
                            >

                                Dipinjam

                            </span>


                        <?php else: ?>


                            <span
                                class="status status-dikembalikan"
                            >

                                Dikembalikan

                            </span>


                        <?php endif; ?>


                    </td>


                    <!-- =========================
                         AKSI
                    ========================= -->

                    <td>


                        <?php

                        if (
                            $data['status']
                            == 'Dipinjam'
                        ):

                        ?>


                            <!-- TOMBOL KEMBALIKAN -->

                            <a
                                href="kembalikan_buku.php?id=<?= $data['id_peminjaman'] ?>"
                                class="btn btn-success"
                                onclick="return confirm('Yakin buku ini sudah dikembalikan?')"
                            >

                                ↩ Kembalikan

                            </a>


                        <?php else: ?>


                            <span
                                style="
                                    color:#94a3b8;
                                    font-size:12px;
                                "
                            >

                                ✓ Selesai

                            </span>


                        <?php endif; ?>


                        <!-- =========================
                             TOMBOL HAPUS
                        ========================= -->

                        <a
                            href="peminjaman.php?hapus=<?= $data['id_peminjaman'] ?>"
                            class="btn-hapus"
                            onclick="return confirm(
                                'Yakin ingin menghapus data peminjaman <?= htmlspecialchars($data['nama_peminjam'], ENT_QUOTES) ?>?'
                            )"
                        >

                            🗑️ Hapus

                        </a>


                    </td>


                </tr>


            <?php

                endwhile;

            else:

            ?>


                <tr>

                    <td
                        colspan="7"
                        style="
                            text-align:center;
                            padding:45px;
                            color:#94a3b8;
                        "
                    >

                        📋

                        <br><br>

                        Belum ada data peminjaman.

                        <br><br>

                        <a
                            href="tambah_peminjaman.php"
                            class="btn btn-primary"
                        >

                            ＋ Tambah Peminjaman

                        </a>

                    </td>

                </tr>


            <?php endif; ?>


            </tbody>


        </table>


    </div>


</div>


</body>

</html>