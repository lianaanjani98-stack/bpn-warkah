<?php

session_start();

include "config/koneksi.php";

$username = $_POST['username'];
$password = $_POST['password'];

$query = mysqli_query(
    $koneksi,
    "SELECT * FROM admin
     WHERE username='$username'
     AND password='$password'"
);

if (mysqli_num_rows($query) > 0) {

    $admin = mysqli_fetch_assoc($query);

    $_SESSION['admin'] = $admin['username'];

    header("Location: dashboard.php");
    exit;

} else {

    echo "<script>
            alert('Username atau password salah!');
            window.location='login.php';
          </script>";

}

?>