<?php

session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

include "config/koneksi.php";


$id = $_GET['id'];


$query = mysqli_query(
    $koneksi,
    "DELETE FROM buku
     WHERE id_buku='$id'"
);


if ($query) {

    echo "<script>

            alert('Buku berhasil dihapus!');

            window.location='buku.php';

          </script>";

} else {

    echo "<script>

            alert('Buku tidak dapat dihapus karena sudah memiliki data peminjaman.');

            window.location='buku.php';

          </script>";

}

?>