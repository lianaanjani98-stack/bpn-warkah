<?php

session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Tambah Buku | Perpustakaan</title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >

</head>

<body>


<!-- SIDEBAR -->

<div class="sidebar">

    <div class="sidebar-logo">

        <div class="logo-icon">
            📚
        </div>

        <div class="logo-text">
            Perpustakaan<span>.</span>
        </div>

    </div>


    <!-- PROFIL ADMIN -->

    <div class="admin-profile">

        <div class="admin-avatar">
            A
        </div>

        <div class="admin-info">

            <strong>
                <?= htmlspecialchars($_SESSION['admin']) ?>
            </strong>

            <small>
                Administrator
            </small>

        </div>

    </div>


    <div class="menu-title">
        Menu Utama
    </div>


    <ul class="sidebar-menu">

        <li>

            <a href="dashboard.php">

                <span>🏠</span>

                Dashboard

            </a>

        </li>


        <li>

            <a
                href="buku.php"
                class="active"
            >

                <span>📖</span>

                Daftar Buku Arsip

            </a>

        </li>


        <li>

            <a href="peminjaman.php">

                <span>📋</span>

                Peminjaman

            </a>

        </li>


        <li>

            <a
                href="logout.php"
                class="logout"
                onclick="return confirm('Yakin ingin logout?')"
            >

                <span>🚪</span>

                Logout

            </a>

        </li>

    </ul>

</div>



<!-- MAIN CONTENT -->

<div class="main-content">


    <!-- HEADER -->

    <div class="top-header">

        <div class="header-left">

            <h1>
                Tambah Buku
            </h1>

            <p>
                Tambahkan koleksi buku baru ke perpustakaan.
            </p>

        </div>


        <div class="header-date">

            📖

            Koleksi Buku

        </div>

    </div>



    <!-- FORM -->

    <div class="form-box">


        <div
            style="
                display:flex;
                align-items:center;
                gap:12px;
                margin-bottom:25px;
            "
        >

            <div
                style="
                    width:48px;
                    height:48px;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    background:#eff6ff;
                    border-radius:12px;
                    font-size:22px;
                "
            >
                📚
            </div>


            <div>

                <h2 style="margin-bottom:3px;">
                    Informasi Buku
                </h2>

                <p
                    style="
                        color:#94a3b8;
                        font-size:11px;
                    "
                >
                    Isi data buku dengan lengkap.
                </p>

            </div>

        </div>



        <form
            action="proses_tambah_buku.php"
            method="POST"
        >


            <!-- JUDUL -->

            <label>
                Judul Buku
            </label>

            <input
                type="text"
                name="judul"
                placeholder="Contoh: Pemrograman Web"
                required
            >



            <!-- TAHUN -->

            <label>
                Tahun Terbit
            </label>

            <input
                type="number"
                name="tahun_terbit"
                placeholder="Contoh: 2025"
                min="1900"
                max="2100"
                required
            >



            <!-- STOK -->

            <label>
                Stok Buku
            </label>

            <input
                type="number"
                name="stok"
                placeholder="Contoh: 10"
                min="0"
                required
            >



            <!-- BUTTON -->

            <div
                style="
                    display:flex;
                    gap:10px;
                    margin-top:8px;
                "
            >

                <button
                    type="submit"
                >

                    💾 Simpan Buku

                </button>


                <a
                    href="buku.php"
                    class="btn btn-secondary"
                >

                    ← Batal

                </a>

            </div>


        </form>


    </div>


</div>


</body>

</html>