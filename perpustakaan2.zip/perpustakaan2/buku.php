<?php

session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

include "config/koneksi.php";

$query = mysqli_query(
    $koneksi,
    "SELECT * FROM buku ORDER BY id_buku DESC"
);

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Daftar Buku</title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >

</head>

<body>


<!-- SIDEBAR -->

<div class="sidebar">

    <div class="sidebar-logo">

        <div class="logo-icon">
            📚
        </div>

        <div class="logo-text">
            Pinjaman Warkah<span>.</span>
        </div>

    </div>


    <!-- PROFIL ADMIN -->

    <div class="admin-profile">

        <div class="admin-avatar">
            A
        </div>

        <div class="admin-info">

            <strong>
                <?= htmlspecialchars($_SESSION['admin']) ?>
            </strong>

            <small>
                Administrator
            </small>

        </div>

    </div>


    <div class="menu-title">
        Menu Utama
    </div>


    <ul class="sidebar-menu">


        <!-- DASHBOARD -->

        <li>

            <a href="dashboard.php">

                <span>🏠</span>

                Dashboard

            </a>

        </li>


        <!-- DAFTAR BUKU -->

        <li>

            <a
                href="buku.php"
                class="active"
            >

                <span>📖</span>

                Daftar Buku Arsip

            </a>

        </li>


        <!-- PEMINJAMAN -->

        <li>

            <a href="peminjaman.php">

                <span>📋</span>

                Peminjaman

            </a>

        </li>


        <!-- LOGOUT -->

        <li>

            <a
                href="logout.php"
                class="logout"
                onclick="return confirm('Yakin ingin logout?')"
            >

                <span>🚪</span>

                Logout

            </a>

        </li>


    </ul>

</div>



<!-- MAIN CONTENT -->

<div class="main-content">


    <!-- HEADER -->

    <div class="top-header">

        <div class="header-left">

            <h1>
                Daftar Buku
            </h1>

            <p>
                Kelola seluruh koleksi buku Arsip SU,GS,SUS.
            </p>

        </div>


        <div class="header-date">

            📚

            Koleksi Buku

        </div>

    </div>



    <!-- CONTENT -->

    <div class="content-box">


        <div class="content-header">


            <div>

                <h2>
                    Data Buku
                </h2>

                <p>
                    Daftar koleksi buku yang tersedia
                </p>

            </div>


            <a
                href="tambah_buku.php"
                class="btn btn-primary"
            >

                ＋ Tambah Buku

            </a>


        </div>



        <!-- TABLE -->

        <table>

            <thead>

                <tr>

                    <th>
                        No
                    </th>

                    <th>
                        Judul Buku
                    </th>

                    <th>
                        Tahun
                    </th>

                    <th>
                        Stok
                    </th>

                    <th>
                        Aksi
                    </th>

                </tr>

            </thead>


            <tbody>


            <?php

            $no = 1;

            if (mysqli_num_rows($query) > 0):

                while (
                    $data = mysqli_fetch_assoc($query)
                ):

            ?>


                <tr>


                    <!-- NO -->

                    <td>

                        <?= $no++ ?>

                    </td>


                    <!-- JUDUL BUKU -->

                    <td>

                        <strong>

                            <?= htmlspecialchars(
                                $data['judul']
                            ) ?>

                        </strong>

                    </td>


                    <!-- TAHUN -->

                    <td>

                        <?= htmlspecialchars(
                            $data['tahun_terbit']
                        ) ?>

                    </td>


                    <!-- STOK -->

                    <td>

                        <?php if ($data['stok'] > 0): ?>

                            <span
                                class="status status-dikembalikan"
                            >

                                <?= $data['stok'] ?>

                                tersedia

                            </span>

                        <?php else: ?>

                            <span
                                class="status status-dipinjam"
                            >

                                Habis

                            </span>

                        <?php endif; ?>

                    </td>


                    <!-- AKSI -->

                    <td>


                        <a
                            href="edit_buku.php?id=<?= $data['id_buku'] ?>"
                            class="btn btn-warning"
                        >

                            ✏️ Edit

                        </a>


                        <a
                            href="hapus_buku.php?id=<?= $data['id_buku'] ?>"
                            class="btn btn-danger"
                            onclick="return confirm('Yakin ingin menghapus buku ini?')"
                        >

                            🗑️ Hapus

                        </a>


                    </td>


                </tr>


            <?php

                endwhile;

            else:

            ?>


                <!-- JIKA BELUM ADA DATA -->

                <tr>

                    <td
                        colspan="5"
                        style="
                            text-align:center;
                            padding:40px;
                            color:#94a3b8;
                        "
                    >

                        📚

                        <br><br>

                        Belum ada data buku.

                        <br><br>

                        <a
                            href="tambah_buku.php"
                            class="btn btn-primary"
                        >

                            ＋ Tambah Buku

                        </a>

                    </td>

                </tr>


            <?php endif; ?>


            </tbody>

        </table>


    </div>


</div>


</body>

</html>