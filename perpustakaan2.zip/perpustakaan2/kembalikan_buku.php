<?php

session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

include "config/koneksi.php";


$id_peminjaman = $_GET['id'];


// AMBIL DATA PEMINJAMAN
$query = mysqli_query(
    $koneksi,
    "SELECT * FROM peminjaman
     WHERE id_peminjaman='$id_peminjaman'"
);


$data = mysqli_fetch_assoc($query);


if (!$data) {

    echo "<script>

            alert('Data peminjaman tidak ditemukan!');

            window.location='peminjaman.php';

          </script>";

    exit;

}


if ($data['status'] == 'Dikembalikan') {

    echo "<script>

            alert('Buku sudah dikembalikan!');

            window.location='peminjaman.php';

          </script>";

    exit;

}


$id_buku = $data['id_buku'];


// UPDATE STATUS
$update_peminjaman = mysqli_query(
    $koneksi,
    "UPDATE peminjaman

     SET
        status='Dikembalikan',
        tanggal_kembali=CURDATE()

     WHERE id_peminjaman='$id_peminjaman'"
);


// TAMBAH STOK
$update_stok = mysqli_query(
    $koneksi,
    "UPDATE buku

     SET stok = stok + 1

     WHERE id_buku='$id_buku'"
);


if ($update_peminjaman && $update_stok) {

    echo "<script>

            alert('Buku berhasil dikembalikan!');

            window.location='peminjaman.php';

          </script>";

} else {

    echo "<script>

            alert('Gagal mengembalikan buku!');

            window.location='peminjaman.php';

          </script>";

}

?>