<?php

session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

include "config/koneksi.php";


$judul = $_POST['judul'];
$tahun_terbit = $_POST['tahun_terbit'];
$stok = $_POST['stok'];


$query = mysqli_query(
    $koneksi,
    "INSERT INTO buku
    (judul, tahun_terbit, stok)
    VALUES
    ('$judul', '$tahun_terbit', '$stok')"
);


if ($query) {

    echo "<script>

            alert('Buku berhasil ditambahkan!');

            window.location='buku.php';

          </script>";

} else {

    echo "Gagal menambahkan buku: "
         . mysqli_error($koneksi);

}

?>